package com.example.caculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText display;
    private double currentValue = 0;
    private String currentOperator = null;
    private boolean isOperatorJustSelected = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);

        // Initialize buttons
        setupNumberButtons();
        setupOperatorButtons();
    }

    private void setupNumberButtons() {
        int[] numberButtonIds = {
                R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3,
                R.id.btn4, R.id.btn5, R.id.btn6, R.id.btn7,
                R.id.btn8, R.id.btn9
        };

        View.OnClickListener numberListener = view -> {
            Button button = (Button) view;

            // Replace text if operator was just selected
            if (isOperatorJustSelected) {
                display.setText("");
                isOperatorJustSelected = false;
            }

            display.append(button.getText().toString());
        };

        for (int id : numberButtonIds) {
            findViewById(id).setOnClickListener(numberListener);
        }
    }

    private void setupOperatorButtons() {
        int[] operatorButtonIds = {
                R.id.btnAdd, R.id.btnSubtract, R.id.btnMultiply, R.id.btnDivide
        };

        View.OnClickListener operatorListener = view -> {
            String input = display.getText().toString();

            if (!input.isEmpty()) {
                double inputValue = Double.parseDouble(input);

                if (currentOperator != null) {
                    // Perform the pending calculation
                    currentValue = calculate(currentValue, inputValue, currentOperator);
                    display.setText(String.valueOf(currentValue));
                } else {
                    currentValue = inputValue;
                }

                // Update operator and prepare for next input
                currentOperator = ((Button) view).getText().toString();
                isOperatorJustSelected = true;
            }
        };

        for (int id : operatorButtonIds) {
            findViewById(id).setOnClickListener(operatorListener);
        }

        findViewById(R.id.btnEquals).setOnClickListener(view -> {
            String input = display.getText().toString();

            if (!input.isEmpty() && currentOperator != null) {
                double inputValue = Double.parseDouble(input);
                currentValue = calculate(currentValue, inputValue, currentOperator);
                display.setText(String.valueOf(currentValue));

                // Reset operator after calculation
                currentOperator = null;
            }
        });

        findViewById(R.id.btnClear).setOnClickListener(view -> clearCalculator());
    }

    private double calculate(double value1, double value2, String operator) {
        switch (operator) {
            case "+": return value1 + value2;
            case "-": return value1 - value2;
            case "*": return value1 * value2;
            case "/": return value2 != 0 ? value1 / value2 : Double.NaN;
            default: return 0;
        }
    }

    private void clearCalculator() {
        display.setText("");
        currentValue = 0;
        currentOperator = null;
        isOperatorJustSelected = false;
    }
}
